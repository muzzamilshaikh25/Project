# ElectricityBillingSystem

Electricity Billing System is a software-based application developed in Java programming language. The project aims at serving the department of electricity by computerizing the billing system. It mainly focuses on the calculation of Units consumed during the specified time and the money to be paid to electricity offices. This computerized system will make the overall billing system easy, accessible, comfortable and effective for consumers.

### Languages Used : JAVA

### Frameworks Used: Swing, AWT

### Databases Used : MySQL

### Tools Used     : VSCode
